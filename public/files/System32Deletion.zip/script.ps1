# Define function to maximize the command prompt window
function Maximize-Window {
    $title = (Get-Process | Where-Object { $_.MainWindowTitle -like "*cmd*" }).MainWindowTitle
    if ($title) {
        $wshell = New-Object -ComObject wscript.shell
        $wshell.AppActivate($title)
        Start-Sleep -Seconds 1
        $wshell.SendKeys('% {UP}')
    } else {
        Write-Host "No Command Prompt window found."
    }
}

# Define function to simulate deleting system files with a delay
function Simulate-CmdOutput {
    $fakeFiles = @(
    "C:\Windows\System32\kernel32.dll",
    "C:\Windows\System32\ntdll.dll",
    "C:\Windows\System32\drivers\etc\hosts",
    "C:\Windows\System32\cmd.exe",
    "C:\Windows\System32\hal.dll",
    "C:\Windows\System32\bootres.dll",
    "C:\Windows\System32\winload.exe"
)

For ($i = 0; $i -lt 50; $i++) {
    $file = Get-Random -InputObject $fakeFiles
    Write-Host "Deleting file: $file ..."
    
    # Delay before printing success message
    Start-Sleep -Seconds (Get-Random -Minimum 0.3 -Maximum 0.7)  # Delay after deleting file
    
    Write-Host " Success."
    
    # Short delay before next file is shown
    Start-Sleep -Seconds (Get-Random -Minimum 0.2 -Maximum 0.5)  # Delay between deletions
}
}

# Define function to simulate glitching effect
function Glitch-Effect {
    $glitchMessages = @(
        "ERROR: System32 directory is corrupted.",
        "WARNING: Critical system file deleted!",
        "ERROR: Missing operating system.",
        "SYSTEM WARNING: Unexpected exception occurred in the kernel.",
        "ERROR: Memory overflow detected.",
        "CRITICAL ERROR: Resource not available.",
        "WARNING: Disk read failure.",
        "ERROR: Unresponsive process detected. Forcing shutdown..."
    )
    
    for ($i = 0; $i -lt 15; $i++) {
        Clear-Host
        $message = $glitchMessages | Get-Random
        Write-Host $message
        # Random delay for each glitch message
        Start-Sleep -Seconds (Get-Random -Minimum 0.2 -Maximum 0.5)
    }
    Start-Sleep -Seconds 1
}

# Main script logic
function Main {
    Maximize-Window

    Clear-Host
    Write-Host "C:\Windows\System32>"
    $answer = Read-Host "Would you like to delete System32? (Y/n)"
    if ($answer -notin @("y", "yes", "n", "no")) {
        $answer = "y"
    }

    Write-Host "`nExecuting: del C:\Windows\System32\*.* /s /q"
    Start-Sleep -Seconds 1.5
    Simulate-CmdOutput

    Write-Host "`nAll files deleted successfully. System may become unstable..."
    Start-Sleep -Seconds 1

    Glitch-Effect

    Write-Host "`nSystem is shutting down..."
    Start-Sleep -Seconds 1.5
    Stop-Computer
}

# Run the script
Main
